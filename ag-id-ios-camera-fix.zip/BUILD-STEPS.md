AG-ID — iOS App Store build package (Capacitor wrapper)

What this is
- A native iOS shell (Apple requires this) that opens https://ag-id.com.au full-screen.
- Bundle ID: au.com.ag-id.app   Version: 1.0 (Build 1)
- Icons, launch screen and encryption exemption are already configured.

How it gets built and sent to Apple (needs an Apple build machine — we use Codemagic's cloud Macs):

1. Put this folder in a GitHub repository (free account → "New repository" → "Upload files" → drag the contents of this folder in).
2. Sign up at codemagic.io with that GitHub account.
3. In Codemagic: Add application → choose the repo → set workflow to iOS.
4. Code signing: choose "Automatic" and let Codemagic create the distribution certificate/profile with your Apple Developer account (it signs in via App Store Connect).
5. Publishing: add an App Store Connect connection (App Store Connect → Users and Access → Integrations → generate an API key, give Codemagic the key ID, issuer ID and the .p8 file).
6. Start the build — when it succeeds it uploads straight to App Store Connect as Build 1, and it appears on your 1.0 submission page within ~10-15 minutes.
7. Back in App Store Connect: select the build in the Build section, then click "Add for Review" / "Submit for Review".


Camera-crash correction — October 22, 2026
- Added NSCameraUsageDescription to ios/App/App/Info.plist. Both Apple crash reports explicitly identify this missing key as the termination reason.
- Source build number is now 4. If Codemagic uses agvtool to set the build number, ensure its chosen value is greater than the previously uploaded Build 3.
- Replace the existing ag-id-ios.zip in the GitHub repository with this archive, retaining that exact filename. Keep the existing Codemagic workflow.
- Run a new Codemagic build and confirm the archived app contains a nonempty NSCameraUsageDescription before upload.
- Test on a physical iPhone/iPad via TestFlight: open Smart scan, tap Scan document, choose Take Photo, allow camera access, take a photo, and confirm document reading succeeds. Also test denying camera access and uploading an existing PDF.
- This source package was checked for valid plist structure, not compiled or tested on an Apple device here.
- DO NOT resubmit yet: the payment-purchase access and login-services rejection issues are not changed by this camera-only correction.
